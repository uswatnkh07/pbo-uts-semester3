package GUI;

import controllers.Suster;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class TambahSuster extends javax.swing.JFrame {
    Suster b1;

    public TambahSuster() throws ClassNotFoundException, SQLException {
        b1 = new Suster();
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCalendar2 = new com.toedter.calendar.JCalendar();
        jCalendar3 = new com.toedter.calendar.JCalendar();
        formAlamat = new javax.swing.JTextField();
        formNama = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        addDatas = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        formUsia = new com.toedter.calendar.JDateChooser();
        formLK = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(formAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 160, 160, 30));

        formNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formNamaActionPerformed(evt);
            }
        });
        getContentPane().add(formNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 160, 30));

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(101, 67, 56));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/nama.png"))); // NOI18N
        jLabel2.setText("Nama");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, 30));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(101, 67, 56));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/alamat.png"))); // NOI18N
        jLabel3.setText("Alamat");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 130, 30));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(101, 67, 56));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/usia.png"))); // NOI18N
        jLabel4.setText("Tanggal Lahir");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 160, 30));

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(101, 67, 56));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/durasi.png"))); // NOI18N
        jLabel5.setText("Tanggal Bergabung");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 200, 30));

        addDatas.setText("Tambah");
        addDatas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addDatasMouseClicked(evt);
            }
        });
        getContentPane().add(addDatas, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 290, -1, -1));

        cancel.setText("Cancel");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, -1, -1));
        getContentPane().add(formUsia, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, 160, 30));
        getContentPane().add(formLK, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, 160, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/TambahSuster1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 320));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_formNamaActionPerformed

    private void addDatasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addDatasMouseClicked
        try {   
            String hb = formNama.getText();
            String jb = formAlamat.getText();
            Date kb = formUsia.getDate();
            Date al = formLK.getDate();

            try {
                b1.insertSuster(hb, jb, kb, al);
            } catch (SQLException ex) {
                Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
            }

            JOptionPane.showMessageDialog(null, "TAMBAH DATA BERHASIL");

            try {
                new DataSuster().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "TAMBAH DATA GAGAL");
            try {
                new TambahSuster().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
    }//GEN-LAST:event_addDatasMouseClicked

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cancelActionPerformed

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        try {
            DataSuster m1 = new DataSuster();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new DataSuster().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TambahSuster.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cancelMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addDatas;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField formAlamat;
    private com.toedter.calendar.JDateChooser formLK;
    private javax.swing.JTextField formNama;
    private com.toedter.calendar.JDateChooser formUsia;
    private com.toedter.calendar.JCalendar jCalendar2;
    private com.toedter.calendar.JCalendar jCalendar3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
