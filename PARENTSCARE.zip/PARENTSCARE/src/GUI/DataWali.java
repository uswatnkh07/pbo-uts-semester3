package GUI;
import javax.swing.*;
import controllers.Wali;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataWali extends javax.swing.JFrame {
    Wali B1;

    public DataWali() throws ClassNotFoundException, SQLException {
        B1 = new Wali();
        initComponents();
        this.showData();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbData = new javax.swing.JTable();
        update = new javax.swing.JButton();
        back = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        create = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nama", "Alamat", "Gender"
            }
        ));
        jScrollPane1.setViewportView(tbData);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(52, 70, 390, 210));

        update.setText("Update");
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        back.setText("Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 290, -1, -1));

        delete.setText("Delete");
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
        });
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, -1, -1));

        create.setText("Create");
        create.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                createMouseClicked(evt);
            }
        });
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        getContentPane().add(create, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/DataWali.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_createActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteActionPerformed

    private void createMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_createMouseClicked
        try {
            new TambahWali().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_createMouseClicked

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        try{ 
            String nama = JOptionPane.showInputDialog("Masukan Nama : ", null); 
            if (nama == null) { 
                try { 
                    new DataWali().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try { 
                    B1.deleteWali(nama); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) {  
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new DataWali().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        }
    }//GEN-LAST:event_deleteMouseClicked

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        try{ 
            String nama = JOptionPane.showInputDialog("Masukan Nama : "); 
            this.dispose();
            if (nama == null) { 
                try { 
                    new DataWali().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try {
                    new upWali(nama).setVisible(true); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new DataWali().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataWali.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        }
    }//GEN-LAST:event_updateMouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        new ListMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backMouseClicked
public void showData() throws SQLException {
        tbData.setModel(new javax.swing.table.DefaultTableModel(
            B1.showWali(),
            new String [] {
                "Nama", "Alamat", "Gender"
            }
        ));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton create;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbData;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
