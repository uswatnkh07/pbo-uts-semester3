package GUI;

import javax.swing.*;
import controllers.Suster;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSuster extends javax.swing.JFrame {
    Suster B1;

    public DataSuster() throws ClassNotFoundException, SQLException {
        B1 = new Suster();
        initComponents();
        this.showData();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbData = new javax.swing.JTable();
        update = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        Create = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nama", "Tgl Lahir", "Alamat", "Tgl Join"
            }
        ));
        jScrollPane1.setViewportView(tbData);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 80, 410, 190));

        update.setText("Update");
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
        });
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, -1, -1));

        Back.setText("Back");
        Back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackMouseClicked(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 300, -1, -1));

        delete.setText("Delete");
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
        });
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, -1, -1));

        Create.setText("Create");
        Create.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CreateMouseClicked(evt);
            }
        });
        getContentPane().add(Create, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 300, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/DataSuster.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateActionPerformed

    private void CreateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateMouseClicked
        try {
            new TambahSuster().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();        
    }//GEN-LAST:event_CreateMouseClicked

    private void BackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackMouseClicked
        new ListMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackMouseClicked

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        try {
        // Get the input from the user
        String nama = JOptionPane.showInputDialog("Masukan Nama : ", null);

        // Check if the input is empty
        if (nama == null) {
            // Display the DataSuster form
            new DataSuster().setVisible(true);

            // Dispose the current form
            this.dispose();
        } else {
            // Display the upSuster form with the input name
            new upSuster(nama).setVisible(true);

            // Refresh the data in the current form
            try {
                this.showData();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error refreshing data: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (Exception e) { // Catch all exceptions
        // Display an error message and log the exception
        JOptionPane.showMessageDialog(this, "Error updating data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, e);

            try {
                // Display the DataSuster form
                new DataSuster().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
            }

        // Dispose the current form
        this.dispose();
    }
    }//GEN-LAST:event_updateMouseClicked

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        try{ 
            String nama = JOptionPane.showInputDialog("Masukan Nama : ", null); 
            if (nama == null) { 
                try { 
                    new DataSuster().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try { 
                    B1.deleteSuster(nama); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new DataSuster().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataSuster.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        }
    }//GEN-LAST:event_deleteMouseClicked
public void showData() throws SQLException {
        tbData.setModel(new javax.swing.table.DefaultTableModel(
            B1.showSuster(),
            new String [] {
                "Nama", "Tgl Lahir", "Alamat", "Tgl Join"
            }
        ));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton Create;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbData;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
