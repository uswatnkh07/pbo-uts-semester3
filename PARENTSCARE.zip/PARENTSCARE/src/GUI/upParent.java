
package GUI;

import controllers.Parent;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class upParent extends javax.swing.JFrame {
    Parent B1;
    int id;

    public upParent(int id) throws ClassNotFoundException, SQLException {
        B1 = new Parent();
        this.id = id;
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        formNama = new javax.swing.JTextField();
        formOrtu = new javax.swing.JTextField();
        formAlergi = new javax.swing.JTextField();
        upData = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        formUsia = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(formNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 72, 170, 30));
        getContentPane().add(formOrtu, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 122, 170, 30));
        getContentPane().add(formAlergi, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 172, 170, 30));

        upData.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        upData.setForeground(new java.awt.Color(125, 46, 46));
        upData.setText("Update");
        upData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upDataMouseClicked(evt);
            }
        });
        getContentPane().add(upData, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, -1, -1));

        cancel.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        cancel.setForeground(new java.awt.Color(125, 46, 46));
        cancel.setText("Cancel");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, -1, -1));

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(125, 46, 46));
        jLabel2.setText("Masukkan Nama");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, -1, -1));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(125, 46, 46));
        jLabel3.setText("Masukkan Nama Wali");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(125, 46, 46));
        jLabel4.setText("Masukkan Tgl Lahir");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, -1, -1));

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(125, 46, 46));
        jLabel5.setText("Riwayat Alergi");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, -1, -1));
        getContentPane().add(formUsia, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 222, 170, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/UpParents1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        try {
            DataParent m1 = new DataParent();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new DataParent().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(upParent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(upParent.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }//GEN-LAST:event_cancelMouseClicked

    private void upDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upDataMouseClicked
        try {    
            String hb = formNama.getText();
            String jb = formOrtu.getText();
            Date kb = formUsia.getDate();
            String al = formAlergi.getText();

            B1.updateparent(id, hb, jb,kb, al);
            
            JOptionPane.showMessageDialog(null, "UBAH DATA BERHASIL");

            new DataParent().setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "UBAH DATA GAGAL");
            try {
                new upParent(id).setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(upParent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(upParent.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
        this.dispose();
    }//GEN-LAST:event_upDataMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel;
    private javax.swing.JTextField formAlergi;
    private javax.swing.JTextField formNama;
    private javax.swing.JTextField formOrtu;
    private com.toedter.calendar.JDateChooser formUsia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton upData;
    // End of variables declaration//GEN-END:variables
}
