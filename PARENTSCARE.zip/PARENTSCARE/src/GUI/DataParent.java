package GUI;
import javax.swing.*;
import controllers.Parent;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataParent extends javax.swing.JFrame {
    Parent P1;

    public DataParent() throws ClassNotFoundException, SQLException {
        P1 = new Parent();
        initComponents();
        this.showData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbData = new javax.swing.JTable();
        Update = new javax.swing.JButton();
        back = new javax.swing.JButton();
        HAPUS = new javax.swing.JButton();
        addData = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nama", "Tgl Lahir", "Wali", "Alergi"
            }
        ));
        jScrollPane1.setViewportView(tbData);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 420, 210));

        Update.setText("Update");
        Update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateMouseClicked(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, -1, -1));

        back.setText("Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 300, -1, -1));

        HAPUS.setText("Delete");
        HAPUS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HAPUSMouseClicked(evt);
            }
        });
        HAPUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HAPUSActionPerformed(evt);
            }
        });
        getContentPane().add(HAPUS, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, -1, -1));

        addData.setText("Creat");
        addData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addDataMouseClicked(evt);
            }
        });
        getContentPane().add(addData, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/DataParents.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void HAPUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HAPUSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HAPUSActionPerformed

    private void addDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addDataMouseClicked
        try {
            new TambahParent().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_addDataMouseClicked

    private void UpdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateMouseClicked
        try{ 
            String id = JOptionPane.showInputDialog("Masukan ID : ", null); 
            this.dispose();
            if (id == null) { 
                try { 
                    new DataParent().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                    new upParent(Integer.parseInt(id)).setVisible(true); 
                try {
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new DataParent().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        } 
    }//GEN-LAST:event_UpdateMouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        new ListMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backMouseClicked

    private void HAPUSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HAPUSMouseClicked
        try{ 
            String id = JOptionPane.showInputDialog("Masukan ID : ", null); 
            if (id == null) { 
                try { 
                    new DataParent().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try { 
                    P1.deleteparent(Integer.parseInt(id)); 
                } catch (SQLException ex) { 
                    Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        }
        
        catch (Exception e) { 
            try { 
                new DataParent().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(DataParent.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        } 
    }//GEN-LAST:event_HAPUSMouseClicked
public void showData() throws SQLException {
        tbData.setModel(new javax.swing.table.DefaultTableModel(
            P1.showparent(),
            new String [] {
                "ID", "Nama", "Tgl Lahir", "Wali", "Alergi"
            }
        ));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HAPUS;
    private javax.swing.JButton Update;
    private javax.swing.JButton addData;
    private javax.swing.JButton back;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbData;
    // End of variables declaration//GEN-END:variables
}
