package GUI;

import controllers.Parent;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class TambahParent extends javax.swing.JFrame {
    Parent b1;

    public TambahParent() throws ClassNotFoundException, SQLException {
        b1 = new Parent();
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        formOrtu = new javax.swing.JTextField();
        formAlergi = new javax.swing.JTextField();
        formNama = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        addDatas = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        formUsia = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        formOrtu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formOrtuActionPerformed(evt);
            }
        });
        getContentPane().add(formOrtu, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 180, 30));

        formAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formAlergiActionPerformed(evt);
            }
        });
        getContentPane().add(formAlergi, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 180, 180, 30));
        getContentPane().add(formNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 180, 30));

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(101, 67, 56));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/data parents.png"))); // NOI18N
        jLabel2.setText("Nama Parent");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 160, 30));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(101, 67, 56));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/nama.png"))); // NOI18N
        jLabel3.setText("Nama Wali");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 150, 30));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(101, 67, 56));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/usia.png"))); // NOI18N
        jLabel4.setText("Tanggal Lahir");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 160, 30));

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(101, 67, 56));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/data alergi.png"))); // NOI18N
        jLabel5.setText("Riwayat Alergi");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 170, 30));

        addDatas.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        addDatas.setForeground(new java.awt.Color(101, 67, 56));
        addDatas.setText("Tambah");
        addDatas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addDatasMouseClicked(evt);
            }
        });
        addDatas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDatasActionPerformed(evt);
            }
        });
        getContentPane().add(addDatas, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, -1, -1));

        cancel.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        cancel.setForeground(new java.awt.Color(101, 67, 56));
        cancel.setText("Cancel");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 300, -1, -1));
        getContentPane().add(formUsia, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 230, 180, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/TambahParents1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formOrtuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formOrtuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_formOrtuActionPerformed

    private void formAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formAlergiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_formAlergiActionPerformed

    private void addDatasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDatasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addDatasActionPerformed

    private void addDatasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addDatasMouseClicked
        try {    
            String hb = formNama.getText();
            String jb = formOrtu.getText();
            Date kb = formUsia.getDate();
            String al = formAlergi.getText();

            b1.insertparent(hb, jb, kb, al);

            JOptionPane.showMessageDialog(null, "TAMBAH DATA BERHASIL");

            new DataParent().setVisible(true);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "TAMBAH DATA GAGAL");
            try {
                new TambahParent().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TambahParent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TambahParent.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
                    
        }
        this.dispose();
    }//GEN-LAST:event_addDatasMouseClicked

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        try {
            DataParent m1 = new DataParent();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new DataParent().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TambahParent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TambahParent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cancelMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addDatas;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField formAlergi;
    private javax.swing.JTextField formNama;
    private javax.swing.JTextField formOrtu;
    private com.toedter.calendar.JDateChooser formUsia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
