package GUI;

import java.sql.SQLException;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ListMenu extends javax.swing.JFrame {

    public ListMenu() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        DataParents = new javax.swing.JButton();
        DataWali = new javax.swing.JButton();
        DataSuster = new javax.swing.JButton();
        Alergi = new javax.swing.JButton();
        Logout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("Kelola Data Parents");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, -1));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("Kelola Data Wali");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 0, 0));
        jLabel4.setText("Kelola Data Suster");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, -1, -1));

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("Informasi Alergi");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, -1, -1));

        DataParents.setText("Mulai");
        DataParents.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DataParentsMouseClicked(evt);
            }
        });
        DataParents.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DataParentsActionPerformed(evt);
            }
        });
        getContentPane().add(DataParents, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 80, -1, -1));

        DataWali.setText("Mulai");
        DataWali.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DataWaliMouseClicked(evt);
            }
        });
        DataWali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DataWaliActionPerformed(evt);
            }
        });
        getContentPane().add(DataWali, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, -1, -1));

        DataSuster.setText("Mulai");
        DataSuster.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DataSusterMouseClicked(evt);
            }
        });
        DataSuster.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DataSusterActionPerformed(evt);
            }
        });
        getContentPane().add(DataSuster, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 180, -1, -1));

        Alergi.setText("Mulai");
        Alergi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AlergiMouseClicked(evt);
            }
        });
        Alergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlergiActionPerformed(evt);
            }
        });
        getContentPane().add(Alergi, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, -1, -1));

        Logout.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        Logout.setForeground(new java.awt.Color(204, 0, 0));
        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/logout.png"))); // NOI18N
        Logout.setText("LOGOUT");
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
        });
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        getContentPane().add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 160, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/ListMenu.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DataParentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DataParentsActionPerformed

    }//GEN-LAST:event_DataParentsActionPerformed

    private void DataWaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DataWaliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DataWaliActionPerformed

    private void AlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlergiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AlergiActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LogoutActionPerformed

    private void DataSusterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DataSusterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DataSusterActionPerformed

    private void DataParentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DataParentsMouseClicked
        try {
            new DataParent().setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            // Tangkap pengecualian umum (Exception) untuk melihat pesan kesalahan
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, "Terjadi kesalahan: " + ex.getMessage(), ex);
        }
    }//GEN-LAST:event_DataParentsMouseClicked

    private void DataWaliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DataWaliMouseClicked
        try {
            new DataWali().setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            // Tangkap pengecualian umum (Exception) untuk melihat pesan kesalahan
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, "Terjadi kesalahan: " + ex.getMessage(), ex);
        }
    }//GEN-LAST:event_DataWaliMouseClicked

    private void DataSusterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DataSusterMouseClicked
        try {
            new DataSuster().setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            // Tangkap pengecualian umum (Exception) untuk melihat pesan kesalahan
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, "Terjadi kesalahan: " + ex.getMessage(), ex);
        }
    }//GEN-LAST:event_DataSusterMouseClicked

    private void AlergiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AlergiMouseClicked
        try {
            new DataAlergi().setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            // Tangkap pengecualian umum (Exception) untuk melihat pesan kesalahan
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, "Terjadi kesalahan: " + ex.getMessage(), ex);
        }
    }//GEN-LAST:event_AlergiMouseClicked

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        JOptionPane.showMessageDialog(null, "ANDA AKAN LOGOUT");
        try {
            new Login().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ListMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alergi;
    private javax.swing.JButton DataParents;
    private javax.swing.JButton DataSuster;
    private javax.swing.JButton DataWali;
    private javax.swing.JButton Logout;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
