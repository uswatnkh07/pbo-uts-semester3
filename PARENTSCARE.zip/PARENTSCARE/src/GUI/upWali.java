package GUI;

import controllers.Wali;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class upWali extends javax.swing.JFrame {
    Wali B1;
    String nama;

    public upWali(String nama) throws ClassNotFoundException, SQLException {
        B1 = new Wali();
        this.nama = nama;
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        formAlamats = new javax.swing.JTextField();
        formGender = new javax.swing.JTextField();
        upData = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(125, 46, 46));
        jLabel2.setText("Masukkan Alamat");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, -1, -1));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(125, 46, 46));
        jLabel3.setText("Masukkan Gender");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        formAlamats.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formAlamatsActionPerformed(evt);
            }
        });
        getContentPane().add(formAlamats, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 260, 30));
        getContentPane().add(formGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, 260, 30));

        upData.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        upData.setForeground(new java.awt.Color(125, 46, 46));
        upData.setText("Update");
        upData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upDataMouseClicked(evt);
            }
        });
        getContentPane().add(upData, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, -1, -1));

        cancel.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        cancel.setForeground(new java.awt.Color(125, 46, 46));
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 300, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/UpWali1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formAlamatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formAlamatsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_formAlamatsActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        try {
            DataWali m1 = new DataWali();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new DataWali().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(upWali.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(upWali.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }//GEN-LAST:event_cancelActionPerformed

    private void upDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upDataMouseClicked
        try {    
            String hb = formAlamats.getText();
            String jb = formGender.getText();

            try {
                B1.updateWali(nama, hb, jb);
            } catch (SQLException ex) {
                Logger.getLogger(upWali.class.getName()).log(Level.SEVERE, null, ex);
            }


            JOptionPane.showMessageDialog(null, "UBAH DATA BERHASIL");


            new ListMenu().setVisible(true);
           
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "UBAH DATA GAGAL");
            try {
                new upWali(nama).setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(upWali.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(upWali.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
        this.dispose();
    }//GEN-LAST:event_upDataMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel;
    private javax.swing.JTextField formAlamats;
    private javax.swing.JTextField formGender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton upData;
    // End of variables declaration//GEN-END:variables
}
