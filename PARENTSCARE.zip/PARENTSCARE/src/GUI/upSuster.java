package GUI;

import controllers.Suster;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class upSuster extends javax.swing.JFrame {
    Suster B1;
    String nama;


    public upSuster(String nama) throws ClassNotFoundException, SQLException {
        B1 = new Suster();
        this.nama = nama;
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        upData = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        formAlamat = new javax.swing.JTextField();
        formUsia = new com.toedter.calendar.JDateChooser();
        formRentang = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(125, 46, 46));
        jLabel2.setText("Masukkan Alamat");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, -1));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(125, 46, 46));
        jLabel3.setText("Masukkan Tgl Lahir");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, -1, -1));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(125, 46, 46));
        jLabel4.setText("Masukkan Durasi ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        upData.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        upData.setForeground(new java.awt.Color(125, 46, 46));
        upData.setText("Update");
        upData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upDataMouseClicked(evt);
            }
        });
        upData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upDataActionPerformed(evt);
            }
        });
        getContentPane().add(upData, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, -1, -1));

        cancel.setFont(new java.awt.Font("Century", 1, 12)); // NOI18N
        cancel.setForeground(new java.awt.Color(125, 46, 46));
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        getContentPane().add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, -1, -1));
        getContentPane().add(formAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 180, 30));
        getContentPane().add(formUsia, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 152, 180, 30));
        getContentPane().add(formRentang, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 202, 180, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/UpSuster1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        try {
            DataSuster m1 = new DataSuster();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new DataSuster().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cancelActionPerformed

    private void upDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upDataActionPerformed

    private void upDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upDataMouseClicked
        try {
            String hb = formAlamat.getText();
            Date jb = formUsia.getDate();
            Date kb = formRentang.getDate();

            try {
                B1.updateSuster(nama, hb, jb, kb);
            } catch (SQLException ex) {
                Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
            }

            JOptionPane.showMessageDialog(null, "UBAH DATA BERHASIL");

            new DataSuster().setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "UBAH DATA GAGAL");
            try {
                new upSuster(nama).setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(upSuster.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
        this.dispose();
    }//GEN-LAST:event_upDataMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel;
    private javax.swing.JTextField formAlamat;
    private com.toedter.calendar.JDateChooser formRentang;
    private com.toedter.calendar.JDateChooser formUsia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JButton upData;
    // End of variables declaration//GEN-END:variables
}
