package database;

public interface DBint {
    public void setQuery(String sql);
    
    public String getQuery();
}
