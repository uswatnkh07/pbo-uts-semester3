package controllers;

import java.sql.SQLException;
import database.Database;
import java.text.SimpleDateFormat;
import java.util.Date;

//Nama, Umur, Alamat, LamaKerja
public class Suster extends Database{
    public Suster() throws ClassNotFoundException, SQLException {
        super();
    }
    
    // Create
    public void insertSuster(String nama, String alamat, Date usia, Date durasi) throws SQLException {
        // Konversi tanggal ke format yang sesuai dengan database
        String tanggal_lahir = new SimpleDateFormat("yyyy-MM-dd").format(usia);
        String tanggal_bergabung = new SimpleDateFormat("yyyy-MM-dd").format(durasi);

        // Buat string SQL
        String sql = String.format("INSERT INTO suster (nama, tanggal_lahir, alamat, tanggal_bergabung) VALUE ('%s', '%s', '%s', '%s')", nama, tanggal_lahir, alamat, tanggal_bergabung);

        // Set query
        this.setQuery(sql);

        // Execute query
        this.execute();
    }

    // Read
    public void getAll() throws SQLException {
        String sql = "SELECT * FROM suster";
        this.setQuery(sql);
        this.fetch();
    }
    
    // Update
    public void updateSuster(String nama, String alamat, Date usia, Date durasi) throws SQLException {
        // Konversi tanggal ke format yang sesuai dengan database
        String tanggal_lahir = new SimpleDateFormat("yyyy-MM-dd").format(usia);
        String tanggal_bergabung = new SimpleDateFormat("yyyy-MM-dd").format(durasi);
        
        // Buat string SQL
        String sql = String.format("UPDATE suster SET tanggal_lahir = '%s' , alamat = '%s', tanggal_bergabung = '%s' WHERE nama = '%s'",
                tanggal_lahir, alamat, tanggal_bergabung, nama);
        
        // Set query
        this.setQuery(sql);
        
        // Execute query
        this.execute();
    }

    // Delete
    public void deleteSuster(String nama) throws SQLException {
        String sql = String.format("DELETE FROM suster WHERE nama  = '%s'", nama);
        this.execute();
    }

    // Validation untuk mencegah redudansi data
    public boolean checkSuster(String nama) throws SQLException {
        getAll();
        while (this.value.next()) {
            if (this.value.getString("suster") == nama) {
                return false;
            }
        }
        return true;
    }
    
    // Print Suster
    public String[][] showSuster() throws SQLException {
        String[][] data = new String[this.lenSuster()][4];
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            String namaSuster = this.value.getString("nama");
            Date tanggalLahir = this.value.getDate("tanggal_lahir");
            String alamat = this.value.getString("alamat");
            Date tanggalBergabung = this.value.getDate("tanggal_bergabung");

            data[i][0] = namaSuster;
            data[i][1] = new SimpleDateFormat("yyyy-dd-MM").format(tanggalLahir);
            data[i][2] = alamat;
            data[i][3] = new SimpleDateFormat("yyyy-dd-MM").format(tanggalBergabung);

            i++;
        }
        return data;
    }
    
    
    
    public int lenSuster() throws SQLException {
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}
