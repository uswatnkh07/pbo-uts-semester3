package controllers;

import java.sql.SQLException;
import database.Database;


public class Wali extends Database{
    public Wali() throws ClassNotFoundException, SQLException {
        super();
    } 
    
        
    // Create
    public void insertWali(String nama, String alamat, String gender) throws SQLException {
        String sql = String.format("INSERT INTO wali (nama, alamat, gender) VALUE ('%s', '%s', '%s')", nama,
                alamat, gender);
        this.setQuery(sql);
        this.execute();
    }

    // Read
    public void getAll() throws SQLException {
        String sql = "SELECT * FROM wali";
        this.setQuery(sql);
        this.fetch();
    }
    
    // Update
    public void updateWali(String nama, String alamat, String gender) throws SQLException {
        String sql = String.format("UPDATE wali SET alamat = '%s' , gender = '%s' WHERE nama = '%s'", alamat, gender, nama);
        this.setQuery(sql);
        this.execute();
    }

    // Delete
    public void deleteWali(String id) throws SQLException {
        String sql = String.format("DELETE FROM wali WHERE nama = '%s'", id);
        this.setQuery(sql);
        this.execute();
    }

    // Validation untuk mencegah redudansi data
    public boolean checkWali(String nama) throws SQLException {
        getAll();
        while (this.value.next()) {
            if (this.value.getString("wali") == nama) {
                return false;
            }
        }
        return true;
    }

    // Print Suster
    public String[][] showWali() throws SQLException {
        String[][] data = new String[this.lenWali()][3];
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) { 
            data[i][0] = this.value.getString("nama");
            data[i][1] = this.value.getString("alamat");
            data[i][2] = this.value.getString("gender");
            i++;
        }
        return data;
    }
    
    public int lenWali() throws SQLException {
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}

