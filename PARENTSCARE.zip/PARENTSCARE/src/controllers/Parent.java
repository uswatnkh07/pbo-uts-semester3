package controllers;

import java.sql.SQLException;
import database.Database;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Parent extends Database {
    // Constructor untuk Connect ke Database
    public Parent() throws ClassNotFoundException, SQLException {
        super();
    }

    // Create
    public void insertparent(String nama, String wali, Date usia, String alergi) throws SQLException {
        // Konversi tanggal ke format yang sesuai dengan database
        String tanggal_lahir = new SimpleDateFormat("yyyy-MM-dd").format(usia);

        // Buat string SQL
        String sql = String.format("INSERT INTO parent (nama_parent, tanggal_lahir, nama_wali, alergi) VALUE ('%s', '%s', '%s', '%s')", nama, tanggal_lahir, wali, alergi);

        // Set query
        this.setQuery(sql);

        // Execute query
        this.execute();
    }

    // Read
    public void getAll() throws SQLException {
        String sql = "SELECT * FROM parent";
        this.setQuery(sql);
        this.fetch();
    }
    
   // Update
    public void updateparent(int id, String nama, String wali, Date usia, String alergi) throws SQLException {
        // Konversi tanggal ke format yang sesuai dengan database
        String tanggal_lahir = new SimpleDateFormat("yyyy-MM-dd").format(usia);

        // Buat string SQL
        String sql = String.format("UPDATE parent SET nama_parent = '%s', tanggal_lahir = '%s', nama_wali = '%s', alergi = '%s' WHERE id_penitipan = %d",
            nama, tanggal_lahir, wali, alergi, id);

        // Set query
        this.setQuery(sql);

        // Execute query
        this.execute();
    }

    // Delete
    public void deleteparent(int id) throws SQLException {
        String sql = String.format("DELETE FROM parent WHERE id_penitipan = %d", id);
        this.setQuery(sql);
        this.execute();
    }

    // Validation untuk mencegah redudansi data
    public boolean checkparent(String nama) throws SQLException {
        getAll();
        while (this.value.next()) {
            if (this.value.getString("parent") == nama) {
                return false;
            }
        }
        return true;
    }

    // Print parent
    public String[][] showparent() throws SQLException {
        String[][] data = new String[this.lenparent()][5];
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            int idPenitipan = this.value.getInt("id_penitipan");
            String namaParent = this.value.getString("nama_parent");
            Date tanggalLahir = this.value.getDate("tanggal_lahir");
            String namaWali = this.value.getString("nama_wali");
            String alergi = this.value.getString("alergi");

            data[i][0] = String.valueOf(idPenitipan);
            data[i][1] = namaParent;
            data[i][2] = new SimpleDateFormat("yyyy-dd-MM").format(tanggalLahir);
            data[i][3] = namaWali;
            data[i][4] = alergi;

            i++;
        }
        return data;
    }
    
    public int lenparent() throws SQLException {
        getAll();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}

